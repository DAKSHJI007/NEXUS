/*
# Multi-user dashboard: profiles, settings, todos, notes upgrade

## Overview
Upgrades NEXUS from a single-tenant demo to a real multi-user personal dashboard.
Each authenticated user gets their own private notes, todos, profile, and settings
that sync across devices. Adds tags to notes, due dates to todos, and a per-user
settings table for theme/widget layout preferences.

## New Tables

### profiles
- `id` (uuid, PK, references auth.users) — one row per user
- `display_name` (text) — chosen during onboarding
- `avatar_url` (text, nullable) — profile picture URL
- `created_at` (timestamptz)

### user_settings
- `user_id` (uuid, PK, references auth.users) — one settings row per user
- `theme` (text, default 'dark') — 'dark' | 'light'
- `accent_color` (text, default 'sky') — accent color key
- `background` (text, default 'particles') — background style key
- `timezone` (text, default 'UTC') — IANA timezone string
- `widget_layout` (jsonb, default '[]') — ordered array of widget IDs
- `widget_visibility` (jsonb, default '{}') — map of widget ID -> boolean
- `onboarded` (boolean, default false) — whether onboarding wizard completed
- `updated_at` (timestamptz)

### todos
- `id` (uuid, PK)
- `user_id` (uuid, NOT NULL, DEFAULT auth.uid(), references auth.users)
- `title` (text, NOT NULL)
- `completed` (boolean, default false)
- `due_date` (date, nullable) — optional due date
- `created_at` (timestamptz)

## Modified Tables

### notes (existing)
- ADD `user_id` (uuid, DEFAULT auth.uid()) — owner column for multi-user isolation
- ADD `tags` (text[], default '{}') — array of tag strings for filtering

## Security
- RLS enabled on all tables.
- profiles: owner can read/update own row (insert handled by trigger or on signup).
- user_settings: owner-scoped CRUD (upsert on first save).
- todos: owner-scoped CRUD.
- notes: policies changed from anon-public to owner-scoped (authenticated only).
- All owner columns default to auth.uid() so inserts that omit user_id succeed.
*/

-- ============================================================
-- profiles
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL DEFAULT '',
  avatar_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============================================================
-- user_settings
-- ============================================================
CREATE TABLE IF NOT EXISTS user_settings (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  theme text NOT NULL DEFAULT 'dark' CHECK (theme IN ('dark', 'light')),
  accent_color text NOT NULL DEFAULT 'sky',
  background text NOT NULL DEFAULT 'particles',
  timezone text NOT NULL DEFAULT 'UTC',
  widget_layout jsonb NOT NULL DEFAULT '[]'::jsonb,
  widget_visibility jsonb NOT NULL DEFAULT '{}'::jsonb,
  onboarded boolean NOT NULL DEFAULT false,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_settings" ON user_settings;
CREATE POLICY "select_own_settings" ON user_settings FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_settings" ON user_settings;
CREATE POLICY "insert_own_settings" ON user_settings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_settings" ON user_settings;
CREATE POLICY "update_own_settings" ON user_settings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_settings" ON user_settings;
CREATE POLICY "delete_own_settings" ON user_settings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- todos
-- ============================================================
CREATE TABLE IF NOT EXISTS todos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  completed boolean NOT NULL DEFAULT false,
  due_date date,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS todos_user_created_idx ON todos (user_id, created_at DESC);

ALTER TABLE todos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_todos" ON todos;
CREATE POLICY "select_own_todos" ON todos FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_todos" ON todos;
CREATE POLICY "insert_own_todos" ON todos FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_todos" ON todos;
CREATE POLICY "update_own_todos" ON todos FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_todos" ON todos;
CREATE POLICY "delete_own_todos" ON todos FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- notes: add user_id and tags columns
-- ============================================================
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'notes' AND column_name = 'user_id') THEN
    ALTER TABLE notes ADD COLUMN user_id uuid DEFAULT auth.uid();
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'notes' AND column_name = 'tags') THEN
    ALTER TABLE notes ADD COLUMN tags text[] NOT NULL DEFAULT '{}';
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS notes_user_created_idx ON notes (user_id, created_at DESC);

-- Replace anon-public policies with owner-scoped policies
DROP POLICY IF EXISTS "anon_select_notes" ON notes;
DROP POLICY IF EXISTS "anon_insert_notes" ON notes;
DROP POLICY IF EXISTS "anon_update_notes" ON notes;
DROP POLICY IF EXISTS "anon_delete_notes" ON notes;

DROP POLICY IF EXISTS "select_own_notes" ON notes;
CREATE POLICY "select_own_notes" ON notes FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_notes" ON notes;
CREATE POLICY "insert_own_notes" ON notes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_notes" ON notes;
CREATE POLICY "update_own_notes" ON notes FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_notes" ON notes;
CREATE POLICY "delete_own_notes" ON notes FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
