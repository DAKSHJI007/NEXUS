import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { supabase, type UserSettings, type Theme, type BackgroundStyle } from '@/lib/supabase';
import { useAuth } from './AuthContext';

const DEFAULT_LAYOUT = ['clock', 'weather', 'todos', 'notes', 'pomodoro', 'news'];
const DEFAULT_VISIBILITY: Record<string, boolean> = {
  clock: true,
  weather: true,
  todos: true,
  notes: true,
  pomodoro: true,
  news: true,
};

const DEFAULT_SETTINGS: Omit<UserSettings, 'user_id' | 'updated_at'> = {
  theme: 'dark',
  accent_color: 'sky',
  background: 'particles',
  timezone: 'UTC',
  widget_layout: DEFAULT_LAYOUT,
  widget_visibility: DEFAULT_VISIBILITY,
  onboarded: false,
};

type SettingsContextValue = {
  settings: UserSettings | null;
  loading: boolean;
  updateSettings: (patch: Partial<UserSettings>) => Promise<void>;
  toggleWidget: (id: string) => Promise<void>;
  reorderWidgets: (layout: string[]) => Promise<void>;
};

const SettingsContext = createContext<SettingsContextValue | undefined>(undefined);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async (uid: string) => {
    setLoading(true);
    const { data, error } = await supabase
      .from('user_settings')
      .select('*')
      .eq('user_id', uid)
      .maybeSingle();
    if (!error && data) {
      setSettings(data as UserSettings);
    } else {
      // Create default settings row
      const insert = { ...DEFAULT_SETTINGS, user_id: uid };
      const { data: created, error: insErr } = await supabase
        .from('user_settings')
        .insert(insert)
        .select('*')
        .maybeSingle();
      if (!insErr && created) setSettings(created as UserSettings);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    if (user) load(user.id);
    else {
      setSettings(null);
      setLoading(false);
    }
  }, [user, load]);

  const updateSettings = useCallback(
    async (patch: Partial<UserSettings>) => {
      if (!user) return;
      const merged = { ...settings, ...patch, user_id: user.id, updated_at: new Date().toISOString() };
      setSettings(merged as UserSettings);
      const { user_id, updated_at, ...rest } = merged as UserSettings;
      void user_id; void updated_at;
      await supabase
        .from('user_settings')
        .upsert({ ...rest, user_id: user.id, updated_at: new Date().toISOString() });
    },
    [user, settings]
  );

  const toggleWidget = useCallback(
    async (id: string) => {
      if (!settings) return;
      const vis = { ...settings.widget_visibility, [id]: !settings.widget_visibility[id] };
      await updateSettings({ widget_visibility: vis });
    },
    [settings, updateSettings]
  );

  const reorderWidgets = useCallback(
    async (layout: string[]) => {
      await updateSettings({ widget_layout: layout });
    },
    [updateSettings]
  );

  return (
    <SettingsContext.Provider value={{ settings, loading, updateSettings, toggleWidget, reorderWidgets }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider');
  return ctx;
}

export { DEFAULT_LAYOUT, DEFAULT_VISIBILITY };
export type { Theme, BackgroundStyle };
