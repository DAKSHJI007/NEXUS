import { useEffect, useRef, useState } from 'react';

export function useTicker(intervalMs = 1500) {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return tick;
}

export function useSeries(seed: number, len = 30, drift = 6, intervalMs = 1500) {
  const [series, setSeries] = useState<number[]>(() =>
    Array.from({ length: len }, () => seed + (Math.random() - 0.5) * drift)
  );
  const last = useRef(seed);
  const tick = useTicker(intervalMs);
  useEffect(() => {
    last.current = Math.max(
      0,
      last.current + (Math.random() - 0.5) * drift
    );
    setSeries((s) => [...s.slice(1), last.current]);
  }, [tick, drift]);
  return series;
}
