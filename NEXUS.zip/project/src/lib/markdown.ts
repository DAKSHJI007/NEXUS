type Token = { type: string; content: string };

export function renderMarkdown(md: string): string {
  const esc = (s: string) =>
    s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const lines = md.split('\n');
  let html = '';
  let inList: 'ul' | 'ol' | null = null;
  let inCode = false;
  let inBlockquote = false;

  const closeList = () => {
    if (inList) { html += `</${inList}>`; inList = null; }
  };
  const closeQuote = () => {
    if (inBlockquote) { html += '</blockquote>'; inBlockquote = false; }
  };

  const inline = (text: string): string => {
    let t = esc(text);
    t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/\*([^*]+)\*/g, '<em>$1</em>');
    t = t.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    return t;
  };

  for (const raw of lines) {
    const line = raw.trimEnd();

    if (line.startsWith('```')) {
      if (inCode) { html += '</code></pre>'; inCode = false; }
      else { closeList(); closeQuote(); html += '<pre><code>'; inCode = true; }
      continue;
    }
    if (inCode) { html += esc(line) + '\n'; continue; }

    if (!line) { closeList(); closeQuote(); continue; }

    if (/^#{1,3}\s/.test(line)) {
      closeList(); closeQuote();
      const level = line.match(/^(#{1,3})/)?.[1].length ?? 1;
      html += `<h${level}>${inline(line.replace(/^#{1,3}\s/, ''))}</h${level}>`;
      continue;
    }

    if (/^[-*]\s/.test(line)) {
      closeQuote();
      if (inList !== 'ul') { closeList(); html += '<ul>'; inList = 'ul'; }
      html += `<li>${inline(line.replace(/^[-*]\s/, ''))}</li>`;
      continue;
    }

    if (/^\d+\.\s/.test(line)) {
      closeQuote();
      if (inList !== 'ol') { closeList(); html += '<ol>'; inList = 'ol'; }
      html += `<li>${inline(line.replace(/^\d+\.\s/, ''))}</li>`;
      continue;
    }

    if (line.startsWith('> ')) {
      closeList();
      if (!inBlockquote) { html += '<blockquote>'; inBlockquote = true; }
      html += inline(line.replace(/^>\s/, ''));
      continue;
    }

    closeList(); closeQuote();
    html += `<p>${inline(line)}</p>`;
  }

  closeList(); closeQuote();
  if (inCode) html += '</code></pre>';

  return html;
}
