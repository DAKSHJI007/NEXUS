import { useEffect } from 'react';
import { useSettings } from '@/context/SettingsContext';

export const ACCENTS: Record<string, { name: string; main: string; soft: string; ring: string }> = {
  sky: { name: 'Sky', main: '#38bdf8', soft: 'rgba(56,189,248,0.15)', ring: 'rgba(56,189,248,0.4)' },
  emerald: { name: 'Emerald', main: '#34d399', soft: 'rgba(52,211,153,0.15)', ring: 'rgba(52,211,153,0.4)' },
  amber: { name: 'Amber', main: '#fbbf24', soft: 'rgba(251,191,36,0.15)', ring: 'rgba(251,191,36,0.4)' },
  rose: { name: 'Rose', main: '#fb7185', soft: 'rgba(251,113,133,0.15)', ring: 'rgba(251,113,133,0.4)' },
  cyan: { name: 'Cyan', main: '#22d3ee', soft: 'rgba(34,211,238,0.15)', ring: 'rgba(34,211,238,0.4)' },
};

export function ThemeApplier() {
  const { settings } = useSettings();
  const theme = settings?.theme ?? 'dark';
  const accentKey = settings?.accent_color ?? 'sky';
  const bg = settings?.background ?? 'particles';

  useEffect(() => {
    const root = document.documentElement;
    const accent = ACCENTS[accentKey] ?? ACCENTS.sky;

    if (theme === 'light') {
      root.style.setProperty('--bg-base', '#f1f5f9');
      root.style.setProperty('--bg-panel', 'rgba(255,255,255,0.7)');
      root.style.setProperty('--bg-elevated', '#ffffff');
      root.style.setProperty('--text-primary', '#0f172a');
      root.style.setProperty('--text-secondary', '#475569');
      root.style.setProperty('--text-muted', '#94a3b8');
      root.style.setProperty('--border-soft', 'rgba(15,23,42,0.08)');
      root.style.setProperty('--border-strong', 'rgba(15,23,42,0.15)');
      root.style.setProperty('--overlay', 'rgba(255,255,255,0.6)');
    } else {
      root.style.setProperty('--bg-base', '#020617');
      root.style.setProperty('--bg-panel', 'rgba(2,6,23,0.4)');
      root.style.setProperty('--bg-elevated', 'rgba(15,23,42,0.6)');
      root.style.setProperty('--text-primary', '#e2e8f0');
      root.style.setProperty('--text-secondary', '#94a3b8');
      root.style.setProperty('--text-muted', '#64748b');
      root.style.setProperty('--border-soft', 'rgba(255,255,255,0.06)');
      root.style.setProperty('--border-strong', 'rgba(255,255,255,0.12)');
      root.style.setProperty('--overlay', 'rgba(2,6,23,0.6)');
    }

    root.style.setProperty('--accent', accent.main);
    root.style.setProperty('--accent-soft', accent.soft);
    root.style.setProperty('--accent-ring', accent.ring);
    root.dataset.theme = theme;
    root.dataset.bg = bg;
  }, [theme, accentKey, bg]);

  return null;
}
