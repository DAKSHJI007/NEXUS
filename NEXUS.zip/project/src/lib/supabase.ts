import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(url, anonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type Priority = 'low' | 'normal' | 'high';

export type Note = {
  id: string;
  content: string;
  priority: Priority;
  pinned: boolean;
  tags: string[];
  user_id: string;
  created_at: string;
  updated_at: string;
};

export type Todo = {
  id: string;
  user_id: string;
  title: string;
  completed: boolean;
  due_date: string | null;
  created_at: string;
};

export type Profile = {
  id: string;
  display_name: string;
  avatar_url: string | null;
  created_at: string;
};

export type Theme = 'dark' | 'light';
export type BackgroundStyle = 'particles' | 'grid' | 'aurora' | 'none';

export type UserSettings = {
  user_id: string;
  theme: Theme;
  accent_color: string;
  background: BackgroundStyle;
  timezone: string;
  widget_layout: string[];
  widget_visibility: Record<string, boolean>;
  onboarded: boolean;
  updated_at: string;
};
