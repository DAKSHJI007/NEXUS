import type { ReactNode } from 'react';
import { GripVertical, X } from 'lucide-react';

export default function WidgetShell({
  title,
  icon,
  onRemove,
  children,
  height = 'auto',
}: {
  title: string;
  icon: ReactNode;
  onRemove?: () => void;
  children: ReactNode;
  height?: string;
}) {
  return (
    <div
      className="glass-panel group relative flex flex-col overflow-hidden rounded-2xl transition-colors hover:border-strong"
      style={{ borderColor: 'var(--border-soft)' }}
    >
      <div className="flex items-center gap-2 border-b border-soft px-4 py-3" style={{ borderColor: 'var(--border-soft)' }}>
        <span className="text-accent" style={{ color: 'var(--accent)' }}>{icon}</span>
        <span className="text-xs font-semibold uppercase tracking-[0.15em] text-secondary">{title}</span>
        <div className="ml-auto flex items-center gap-1">
          {onRemove && (
            <button
              onClick={onRemove}
              className="rounded p-1 text-muted opacity-0 transition-all hover:text-rose-400 group-hover:opacity-100"
              title="Hide widget"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
          <GripVertical className="h-4 w-4 cursor-grab text-muted opacity-0 transition-opacity group-hover:opacity-60" />
        </div>
      </div>
      <div className="flex-1 p-4" style={{ minHeight: height }}>
        {children}
      </div>
    </div>
  );
}
