import { useEffect, useRef, useState } from 'react';
import { Timer, Play, Pause, RotateCcw, Coffee } from 'lucide-react';
import WidgetShell from './WidgetShell';

type Mode = 'focus' | 'break';
const DURATIONS: Record<Mode, number> = { focus: 25 * 60, break: 5 * 60 };

export default function PomodoroWidget() {
  const [mode, setMode] = useState<Mode>('focus');
  const [seconds, setSeconds] = useState(DURATIONS.focus);
  const [running, setRunning] = useState(false);
  const [sessions, setSessions] = useState(0);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (running) {
      intervalRef.current = window.setInterval(() => {
        setSeconds((s) => {
          if (s <= 1) {
            if (mode === 'focus') setSessions((n) => n + 1);
            const nextMode: Mode = mode === 'focus' ? 'break' : 'focus';
            setMode(nextMode);
            setRunning(false);
            return DURATIONS[nextMode];
          }
          return s - 1;
        });
      }, 1000);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [running, mode]);

  const switchMode = (m: Mode) => {
    setMode(m);
    setSeconds(DURATIONS[m]);
    setRunning(false);
  };

  const reset = () => {
    setSeconds(DURATIONS[mode]);
    setRunning(false);
  };

  const mm = Math.floor(seconds / 60).toString().padStart(2, '0');
  const ss = (seconds % 60).toString().padStart(2, '0');
  const progress = 1 - seconds / DURATIONS[mode];

  return (
    <WidgetShell title="Focus Timer" icon={<Timer className="h-4 w-4" />} height="auto">
      <div className="flex flex-col items-center py-2">
        <div className="mb-3 flex gap-1 rounded-lg border border-soft p-0.5" style={{ borderColor: 'var(--border-soft)' }}>
          {(['focus', 'break'] as const).map((m) => (
            <button
              key={m}
              onClick={() => switchMode(m)}
              className={`rounded-md px-3 py-1 text-xs font-medium capitalize transition-colors ${
                mode === m ? 'text-white' : 'text-secondary hover:text-primary'
              }`}
              style={mode === m ? { backgroundColor: 'var(--accent)' } : {}}
            >
              {m === 'focus' ? 'Focus' : 'Break'}
            </button>
          ))}
        </div>

        <div className="relative flex h-32 w-32 items-center justify-center">
          <svg className="absolute inset-0 -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="46" fill="none" strokeWidth="3" style={{ stroke: 'var(--border-soft)' }} />
            <circle
              cx="50" cy="50" r="46" fill="none" strokeWidth="3"
              strokeDasharray={2 * Math.PI * 46}
              strokeDashoffset={2 * Math.PI * 46 * (1 - progress)}
              strokeLinecap="round"
              style={{ stroke: 'var(--accent)', transition: 'stroke-dashoffset 1s linear' }}
            />
          </svg>
          <div className="text-center">
            <div className="font-mono text-2xl font-bold tabular-nums text-primary">{mm}:{ss}</div>
            <div className="text-[10px] uppercase tracking-wider text-muted">
              {mode === 'focus' ? 'Stay focused' : 'Take a break'}
            </div>
          </div>
        </div>

        <div className="mt-4 flex items-center gap-2">
          <button
            onClick={() => setRunning((r) => !r)}
            className="flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-semibold text-white"
            style={{ backgroundColor: 'var(--accent)' }}
          >
            {running ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {running ? 'Pause' : 'Start'}
          </button>
          <button
            onClick={reset}
            className="flex items-center gap-1.5 rounded-lg border border-soft px-3 py-2 text-sm text-secondary hover:text-primary"
            style={{ borderColor: 'var(--border-soft)' }}
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-3 flex items-center gap-1.5 text-xs text-secondary">
          <Coffee className="h-3.5 w-3.5" />
          {sessions} session{sessions !== 1 ? 's' : ''} completed
        </div>
      </div>
    </WidgetShell>
  );
}
