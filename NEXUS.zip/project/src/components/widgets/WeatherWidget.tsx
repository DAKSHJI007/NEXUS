import { useEffect, useState } from 'react';
import { CloudSun, Loader2, MapPin, RefreshCw } from 'lucide-react';
import WidgetShell from './WidgetShell';

type WeatherData = {
  current: {
    temperature_2m: number;
    apparent_temperature: number;
    relative_humidity_2m: number;
    weather_code: number;
    wind_speed_10m: number;
  };
  daily: {
    weather_code: number[];
    temperature_2m_max: number[];
    temperature_2m_min: number[];
  };
  timezone: string;
};

const WMO_CODES: Record<number, { label: string; icon: string }> = {
  0: { label: 'Clear', icon: '☀️' },
  1: { label: 'Mainly Clear', icon: '🌤️' },
  2: { label: 'Partly Cloudy', icon: '⛅' },
  3: { label: 'Overcast', icon: '☁️' },
  45: { label: 'Fog', icon: '🌫️' },
  48: { label: 'Rime Fog', icon: '🌫️' },
  51: { label: 'Light Drizzle', icon: '🌦️' },
  53: { label: 'Drizzle', icon: '🌦️' },
  55: { label: 'Heavy Drizzle', icon: '🌧️' },
  61: { label: 'Light Rain', icon: '🌦️' },
  63: { label: 'Rain', icon: '🌧️' },
  65: { label: 'Heavy Rain', icon: '🌧️' },
  71: { label: 'Light Snow', icon: '🌨️' },
  73: { label: 'Snow', icon: '❄️' },
  75: { label: 'Heavy Snow', icon: '❄️' },
  80: { label: 'Showers', icon: '🌦️' },
  81: { label: 'Heavy Showers', icon: '🌧️' },
  82: { label: 'Violent Showers', icon: '⛈️' },
  95: { label: 'Thunderstorm', icon: '⛈️' },
  96: { label: 'Storm + Hail', icon: '⛈️' },
  99: { label: 'Heavy Storm', icon: '⛈️' },
};

export default function WeatherWidget() {
  const [data, setData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [location, setLocation] = useState<{ lat: number; lon: number; name: string } | null>(null);

  const fetchWeather = async (lat: number, lon: number, name: string) => {
    setLoading(true);
    setError(null);
    try {
      const fnUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/widgets/weather?lat=${lat}&lon=${lon}`;
      const resp = await fetch(fnUrl, {
        headers: { Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}` },
      });
      if (!resp.ok) throw new Error('Failed');
      const json = await resp.json();
      if (json.error) throw new Error(json.error);
      setData(json);
      setLocation({ lat, lon, name });
    } catch {
      setError('Unable to load weather');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!navigator.geolocation) {
      fetchWeather(40.71, -74.01, 'New York');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => fetchWeather(pos.coords.latitude, pos.coords.longitude, 'Your location'),
      () => fetchWeather(40.71, -74.01, 'New York'),
      { timeout: 5000 }
    );
  }, []);

  const wmo = data ? WMO_CODES[data.current.weather_code] ?? { label: '—', icon: '🌡️' } : null;

  return (
    <WidgetShell title="Weather" icon={<CloudSun className="h-4 w-4" />} height="200px">
      {loading && (
        <div className="space-y-3">
          <div className="skeleton h-8 w-24" />
          <div className="skeleton h-12 w-32" />
          <div className="skeleton h-4 w-full" />
        </div>
      )}
      {error && !loading && (
        <div className="flex flex-col items-center justify-center gap-2 py-6 text-center">
          <p className="text-sm text-secondary">{error}</p>
          <button
            onClick={() => location && fetchWeather(location.lat, location.lon, location.name)}
            className="flex items-center gap-1.5 rounded-lg border border-soft px-3 py-1.5 text-xs text-secondary hover:text-primary"
            style={{ borderColor: 'var(--border-soft)' }}
          >
            <RefreshCw className="h-3 w-3" /> Retry
          </button>
        </div>
      )}
      {data && !loading && !error && (
        <div className="fade-in">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1 text-xs text-secondary">
                <MapPin className="h-3 w-3" /> {location?.name ?? data.timezone}
              </div>
              <div className="mt-1 text-3xl font-bold text-primary">
                {Math.round(data.current.temperature_2m)}°C
              </div>
              <div className="text-xs text-secondary">
                Feels {Math.round(data.current.apparent_temperature)}°C
              </div>
            </div>
            <div className="text-right">
              <div className="text-4xl">{wmo?.icon}</div>
              <div className="text-xs text-secondary">{wmo?.label}</div>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-4 gap-2 border-t border-soft pt-3" style={{ borderColor: 'var(--border-soft)' }}>
            {data.daily.weather_code.slice(0, 4).map((code, i) => {
              const d = WMO_CODES[code] ?? { label: '—', icon: '🌡️' };
              const day = new Date();
              day.setDate(day.getDate() + i);
              return (
                <div key={i} className="text-center">
                  <div className="text-[10px] uppercase text-muted">
                    {i === 0 ? 'Today' : day.toLocaleDateString('en-US', { weekday: 'short' })}
                  </div>
                  <div className="my-0.5 text-lg">{d.icon}</div>
                  <div className="text-[11px] text-secondary">
                    {Math.round(data.daily.temperature_2m_max[i])}°
                    <span className="text-muted"> / {Math.round(data.daily.temperature_2m_min[i])}°</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </WidgetShell>
  );
}
