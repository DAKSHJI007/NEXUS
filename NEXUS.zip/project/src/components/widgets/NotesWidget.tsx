import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  StickyNote, Plus, Pin, PinOff, Trash2, Search, Tag, Download,
  Loader2, Eye, Pencil, X,
} from 'lucide-react';
import WidgetShell from './WidgetShell';
import { supabase, type Note, type Priority } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { renderMarkdown } from '@/lib/markdown';

const PRIORITY_STYLES: Record<Priority, string> = {
  low: '#34d399',
  normal: '#38bdf8',
  high: '#fb7185',
};

export default function NotesWidget() {
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [content, setContent] = useState('');
  const [priority, setPriority] = useState<Priority>('normal');
  const [tagInput, setTagInput] = useState('');
  const [draftTags, setDraftTags] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [query, setQuery] = useState('');
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [editPreview, setEditPreview] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('notes')
      .select('*')
      .order('pinned', { ascending: false })
      .order('created_at', { ascending: false });
    if (!error && data) setNotes(data as Note[]);
    setLoading(false);
  }, [user]);

  useEffect(() => { load(); }, [load]);

  const allTags = useMemo(() => {
    const set = new Set<string>();
    notes.forEach((n) => n.tags?.forEach((t) => set.add(t)));
    return [...set].sort();
  }, [notes]);

  const filtered = useMemo(() => {
    return notes.filter((n) => {
      const matchesQuery = !query || n.content.toLowerCase().includes(query.toLowerCase());
      const matchesTag = !activeTag || n.tags?.includes(activeTag);
      return matchesQuery && matchesTag;
    });
  }, [notes, query, activeTag]);

  const addTag = () => {
    const t = tagInput.trim().toLowerCase().replace(/^#/, '');
    if (t && !draftTags.includes(t)) setDraftTags((prev) => [...prev, t]);
    setTagInput('');
  };

  const add = async () => {
    const text = content.trim();
    if (!text || saving || !user) return;
    setSaving(true);
    const { data, error } = await supabase
      .from('notes')
      .insert({ content: text, priority, tags: draftTags })
      .select('*')
      .single();
    if (!error && data) {
      setNotes((prev) => [data as Note, ...prev].sort((a, b) => Number(b.pinned) - Number(a.pinned)));
      setContent('');
      setDraftTags([]);
    }
    setSaving(false);
  };

  const togglePin = async (n: Note) => {
    const { error } = await supabase
      .from('notes')
      .update({ pinned: !n.pinned, updated_at: new Date().toISOString() })
      .eq('id', n.id);
    if (!error) load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from('notes').delete().eq('id', id);
    if (!error) setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  const startEdit = (n: Note) => {
    setEditingId(n.id);
    setEditContent(n.content);
    setEditPreview(false);
  };

  const saveEdit = async () => {
    if (!editingId) return;
    const { error } = await supabase
      .from('notes')
      .update({ content: editContent, updated_at: new Date().toISOString() })
      .eq('id', editingId);
    if (!error) {
      setNotes((prev) => prev.map((n) => n.id === editingId ? { ...n, content: editContent } : n));
      setEditingId(null);
      setEditContent('');
    }
  };

  const exportNotes = (format: 'txt' | 'md') => {
    const sorted = [...filtered].sort((a, b) => Number(b.pinned) - Number(a.pinned));
    const body = sorted.map((n) => {
      const tags = n.tags?.length ? ` ${n.tags.map((t) => `#${t}`).join(' ')}` : '';
      const pin = n.pinned ? ' [pinned]' : '';
      const date = new Date(n.created_at).toLocaleString();
      if (format === 'md') {
        return `## ${n.priority.toUpperCase()}${pin} — ${date}\n\n${n.content}${tags}\n`;
      }
      return `[${n.priority.toUpperCase()}]${pin} ${date}\n${n.content}${tags}\n---\n`;
    }).join('\n');
    const blob = new Blob([body], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexus-notes.${format}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <WidgetShell title="Notes" icon={<StickyNote className="h-4 w-4" />} height="420px">
      {/* Composer */}
      <div className="mb-3 space-y-2">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) add(); }}
          placeholder="Write a note… **markdown** supported. ⌘+Enter to save."
          rows={2}
          className="w-full resize-none rounded-lg border border-soft bg-transparent px-3 py-2 text-sm text-primary placeholder:text-muted focus:border-strong focus:outline-none"
          style={{ borderColor: 'var(--border-soft)' }}
        />
        <div className="flex flex-wrap items-center gap-1.5">
          {draftTags.map((t) => (
            <span key={t} className="flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px]" style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}>
              #{t}
              <button onClick={() => setDraftTags((prev) => prev.filter((x) => x !== t))}>
                <X className="h-2.5 w-2.5" />
              </button>
            </span>
          ))}
          <input
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }}
            placeholder="add tag…"
            className="w-20 flex-none rounded-full border border-soft bg-transparent px-2 py-0.5 text-[11px] text-primary placeholder:text-muted focus:outline-none"
            style={{ borderColor: 'var(--border-soft)' }}
          />
          <div className="ml-auto flex items-center gap-1">
            {(['low', 'normal', 'high'] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPriority(p)}
                className="rounded-md px-2 py-1 text-[11px] font-medium capitalize transition-colors"
                style={priority === p ? { backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' } : { color: 'var(--text-secondary)' }}
              >
                {p}
              </button>
            ))}
            <button
              onClick={add}
              disabled={saving || !content.trim()}
              className="flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-semibold text-white disabled:opacity-40"
              style={{ backgroundColor: 'var(--accent)' }}
            >
              {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />}
              Save
            </button>
          </div>
        </div>
      </div>

      {/* Search + tags + export */}
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[120px]">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search notes…"
            className="w-full rounded-lg border border-soft bg-transparent py-1.5 pl-8 pr-3 text-xs text-primary placeholder:text-muted focus:outline-none"
            style={{ borderColor: 'var(--border-soft)' }}
          />
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => exportNotes('md')} title="Export as Markdown" className="rounded p-1.5 text-muted hover:text-primary">
            <Download className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {allTags.length > 0 && (
        <div className="mb-2 flex flex-wrap gap-1">
          <button
            onClick={() => setActiveTag(null)}
            className="rounded-full px-2 py-0.5 text-[11px] transition-colors"
            style={!activeTag ? { background: 'var(--accent-soft)', color: 'var(--accent)' } : { color: 'var(--text-secondary)' }}
          >
            all
          </button>
          {allTags.map((t) => (
            <button
              key={t}
              onClick={() => setActiveTag(activeTag === t ? null : t)}
              className="rounded-full px-2 py-0.5 text-[11px] transition-colors"
              style={activeTag === t ? { background: 'var(--accent-soft)', color: 'var(--accent)' } : { color: 'var(--text-secondary)' }}
            >
              #{t}
            </button>
          ))}
        </div>
      )}

      {/* List */}
      <div className="flex-1 space-y-2 overflow-y-auto" style={{ maxHeight: '240px' }}>
        {loading ? (
          <div className="space-y-2">
            <div className="skeleton h-16 w-full" />
            <div className="skeleton h-16 w-full" />
          </div>
        ) : filtered.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted">
            {notes.length === 0 ? 'No notes yet. Write one above.' : 'No notes match your filter.'}
          </p>
        ) : (
          filtered.map((n) => (
            <div
              key={n.id}
              className="group rounded-lg border border-soft bg-transparent px-3 py-2"
              style={{ borderLeft: `2px solid ${PRIORITY_STYLES[n.priority]}`, borderColor: 'var(--border-soft)' }}
            >
              {editingId === n.id ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-1">
                    <button onClick={() => setEditPreview((p) => !p)} className="rounded p-1 text-muted hover:text-primary">
                      {editPreview ? <Pencil className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                    </button>
                    <span className="text-[10px] uppercase text-muted">{editPreview ? 'preview' : 'edit'}</span>
                    <div className="ml-auto flex gap-1">
                      <button onClick={saveEdit} className="rounded px-2 py-0.5 text-[11px] text-accent" style={{ color: 'var(--accent)' }}>Save</button>
                      <button onClick={() => setEditingId(null)} className="rounded p-1 text-muted hover:text-rose-400">
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                  {editPreview ? (
                    <div className="prose-note text-sm" dangerouslySetInnerHTML={{ __html: renderMarkdown(editContent) }} />
                  ) : (
                    <textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      rows={4}
                      autoFocus
                      className="w-full resize-none rounded-lg border border-soft bg-transparent px-2 py-1 text-sm text-primary focus:outline-none"
                      style={{ borderColor: 'var(--border-soft)' }}
                    />
                  )}
                </div>
              ) : (
                <>
                  <div className="flex items-start gap-2">
                    <div className="prose-note flex-1 text-sm text-primary" dangerouslySetInnerHTML={{ __html: renderMarkdown(n.content) }} />
                    <div className="flex flex-none items-center gap-0.5 opacity-0 transition-opacity group-hover:opacity-100">
                      <button onClick={() => startEdit(n)} className="rounded p-1 text-muted hover:text-primary">
                        <Pencil className="h-3 w-3" />
                      </button>
                      <button onClick={() => togglePin(n)} className="rounded p-1 text-muted hover:text-accent">
                        {n.pinned ? <PinOff className="h-3 w-3" /> : <Pin className="h-3 w-3" />}
                      </button>
                      <button onClick={() => remove(n.id)} className="rounded p-1 text-muted hover:text-rose-400">
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[10px] text-muted">
                    <span style={{ color: PRIORITY_STYLES[n.priority] }}>{n.priority}</span>
                    {n.pinned && <span style={{ color: '#fbbf24' }}>pinned</span>}
                    <span>{new Date(n.created_at).toLocaleDateString()}</span>
                    {n.tags?.map((t) => (
                      <span key={t} className="flex items-center gap-0.5">
                        <Tag className="h-2.5 w-2.5" />{t}
                      </span>
                    ))}
                  </div>
                </>
              )}
            </div>
          ))
        )}
      </div>
    </WidgetShell>
  );
}
