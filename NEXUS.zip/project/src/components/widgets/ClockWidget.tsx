import { useEffect, useState } from 'react';
import { Clock } from 'lucide-react';
import WidgetShell from './WidgetShell';
import { useSettings } from '@/context/SettingsContext';

const TIMEZONES = [
  'UTC', 'America/New_York', 'America/Chicago', 'America/Los_Angeles', 'America/Denver',
  'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'Europe/Madrid',
  'Asia/Tokyo', 'Asia/Shanghai', 'Asia/Kolkata', 'Asia/Dubai',
  'Australia/Sydney', 'Pacific/Auckland',
];

export default function ClockWidget() {
  const { settings, updateSettings } = useSettings();
  const tz = settings?.timezone ?? 'UTC';
  const [now, setNow] = useState(new Date());
  const [pickerOpen, setPickerOpen] = useState(false);

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const time = now.toLocaleTimeString('en-US', { hour12: false, timeZone: tz });
  const date = now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', timeZone: tz });

  const setTz = (zone: string) => {
    updateSettings({ timezone: zone });
    setPickerOpen(false);
  };

  return (
    <WidgetShell title="Clock" icon={<Clock className="h-4 w-4" />} height="auto">
      <div className="flex flex-col items-center justify-center py-2 text-center">
        <div className="font-mono text-4xl font-bold tabular-nums tracking-tight text-primary sm:text-5xl">
          {time}
        </div>
        <div className="mt-1 text-sm text-secondary">{date}</div>
        <div className="relative mt-3">
          <button
            onClick={() => setPickerOpen((o) => !o)}
            className="rounded-full border border-soft px-3 py-1 text-xs text-secondary transition-colors hover:border-strong hover:text-primary"
            style={{ borderColor: 'var(--border-soft)' }}
          >
            {tz}
          </button>
          {pickerOpen && (
            <div className="absolute left-1/2 top-full z-20 mt-1 max-h-48 w-56 -translate-x-1/2 overflow-y-auto rounded-lg border border-strong bg-slate-950/95 p-1 shadow-xl backdrop-blur-xl" style={{ borderColor: 'var(--border-strong)' }}>
              {TIMEZONES.map((zone) => (
                <button
                  key={zone}
                  onClick={() => setTz(zone)}
                  className={`block w-full rounded px-3 py-1.5 text-left text-xs transition-colors hover:bg-white/5 ${zone === tz ? 'text-accent' : 'text-secondary'}`}
                  style={zone === tz ? { color: 'var(--accent)' } : {}}
                >
                  {zone.replace(/_/g, ' ')}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </WidgetShell>
  );
}
