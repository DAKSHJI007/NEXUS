import { useEffect, useState } from 'react';
import { Newspaper, ExternalLink, Loader2, ChevronDown } from 'lucide-react';
import WidgetShell from './WidgetShell';

type FeedItem = {
  title: string;
  link: string;
  pubDate: string | null;
  source: string;
};

const FEEDS = [
  { name: 'Hacker News', url: 'https://hnrss.org/frontpage' },
  { name: 'BBC News', url: 'https://feeds.bbci.co.uk/news/rss.xml' },
  { name: 'TechCrunch', url: 'https://techcrunch.com/feed/' },
  { name: 'The Verge', url: 'https://www.theverge.com/rss/index.xml' },
  { name: 'Reuters', url: 'https://www.reutersagency.com/feed/?best-topics=top-news&post_type=best' },
];

function parseRSS(xml: string): FeedItem[] {
  const doc = new DOMParser().parseFromString(xml, 'text/xml');
  const items = [...doc.querySelectorAll('item, entry')].slice(0, 8);
  return items.map((item) => {
    const title = item.querySelector('title')?.textContent ?? '';
    const link = item.querySelector('link')?.textContent ?? item.querySelector('link')?.getAttribute('href') ?? '';
    const pubDate = item.querySelector('pubDate, published, updated')?.textContent ?? null;
    const source = item.querySelector('source')?.textContent ?? '';
    return { title, link, pubDate, source };
  }).filter((i) => i.title);
}

export default function NewsWidget() {
  const [feedIdx, setFeedIdx] = useState(0);
  const [items, setItems] = useState<FeedItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);

  const load = async (idx: number) => {
    setLoading(true);
    setError(null);
    setPickerOpen(false);
    try {
      const fnUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/widgets/news?url=${encodeURIComponent(FEEDS[idx].url)}`;
      const resp = await fetch(fnUrl, {
        headers: { Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}` },
      });
      if (!resp.ok) throw new Error('Failed');
      const xml = await resp.text();
      const parsed = parseRSS(xml);
      if (parsed.length === 0) throw new Error('No articles');
      setItems(parsed);
    } catch {
      setError('Unable to load feed');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(feedIdx); }, [feedIdx]);

  return (
    <WidgetShell title="News Feed" icon={<Newspaper className="h-4 w-4" />} height="320px">
      <div className="mb-2 flex items-center justify-between">
        <div className="relative">
          <button
            onClick={() => setPickerOpen((o) => !o)}
            className="flex items-center gap-1.5 rounded-lg border border-soft px-2.5 py-1 text-xs text-secondary hover:text-primary"
            style={{ borderColor: 'var(--border-soft)' }}
          >
            {FEEDS[feedIdx].name}
            <ChevronDown className="h-3 w-3" />
          </button>
          {pickerOpen && (
            <div className="absolute left-0 top-full z-20 mt-1 w-40 rounded-lg border border-strong bg-slate-950/95 p-1 shadow-xl backdrop-blur-xl" style={{ borderColor: 'var(--border-strong)' }}>
              {FEEDS.map((f, i) => (
                <button
                  key={f.url}
                  onClick={() => setFeedIdx(i)}
                  className={`block w-full rounded px-3 py-1.5 text-left text-xs transition-colors hover:bg-white/5 ${i === feedIdx ? 'text-accent' : 'text-secondary'}`}
                  style={i === feedIdx ? { color: 'var(--accent)' } : {}}
                >
                  {f.name}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 space-y-1 overflow-y-auto" style={{ maxHeight: '260px' }}>
        {loading && (
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => <div key={i} className="skeleton h-12 w-full" />)}
          </div>
        )}
        {error && !loading && (
          <p className="py-6 text-center text-sm text-muted">{error}</p>
        )}
        {!loading && !error && items.map((item, i) => (
          <a
            key={i}
            href={item.link}
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-start gap-2 rounded-lg border border-transparent px-2 py-1.5 transition-colors hover:border-soft hover:bg-white/5"
          >
            <ExternalLink className="mt-0.5 h-3 w-3 flex-none text-muted transition-colors group-hover:text-accent" />
            <div className="min-w-0 flex-1">
              <p className="line-clamp-2 text-xs text-primary">{item.title}</p>
              {item.pubDate && (
                <span className="text-[10px] text-muted">
                  {new Date(item.pubDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </span>
              )}
            </div>
          </a>
        ))}
      </div>
    </WidgetShell>
  );
}
