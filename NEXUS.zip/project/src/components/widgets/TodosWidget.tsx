import { useCallback, useEffect, useState } from 'react';
import { CheckSquare, Plus, Trash2, Check, Calendar, Loader2 } from 'lucide-react';
import WidgetShell from './WidgetShell';
import { supabase, type Todo } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

export default function TodosWidget() {
  const { user } = useAuth();
  const [todos, setTodos] = useState<Todo[]>([]);
  const [title, setTitle] = useState('');
  const [due, setDue] = useState('');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('todos')
      .select('*')
      .eq('user_id', user.id)
      .order('completed')
      .order('due_date', { nullsFirst: true, ascending: true })
      .order('created_at', { ascending: false });
    if (!error && data) setTodos(data as Todo[]);
    setLoading(false);
  }, [user]);

  useEffect(() => { load(); }, [load]);

  const add = async () => {
    const text = title.trim();
    if (!text || !user) return;
    const { data, error } = await supabase
      .from('todos')
      .insert({ title: text, due_date: due || null })
      .select('*')
      .single();
    if (!error && data) {
      setTodos((prev) => [data as Todo, ...prev]);
      setTitle('');
      setDue('');
    }
  };

  const toggle = async (t: Todo) => {
    const { error } = await supabase
      .from('todos')
      .update({ completed: !t.completed })
      .eq('id', t.id);
    if (!error) setTodos((prev) => prev.map((x) => x.id === t.id ? { ...x, completed: !x.completed } : x));
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from('todos').delete().eq('id', id);
    if (!error) setTodos((prev) => prev.filter((x) => x.id !== id));
  };

  const overdue = (due: string | null) => due && new Date(due) < new Date(new Date().toDateString());

  return (
    <WidgetShell title="To-Do List" icon={<CheckSquare className="h-4 w-4" />} height="280px">
      <div className="mb-3 space-y-2">
        <div className="flex gap-2">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && add()}
            placeholder="Add a task…"
            className="flex-1 rounded-lg border border-soft bg-transparent px-3 py-1.5 text-sm text-primary placeholder:text-muted focus:border-strong focus:outline-none"
            style={{ borderColor: 'var(--border-soft)' }}
          />
          <input
            type="date"
            value={due}
            onChange={(e) => setDue(e.target.value)}
            className="w-32 rounded-lg border border-soft bg-transparent px-2 py-1.5 text-xs text-secondary focus:border-strong focus:outline-none"
            style={{ borderColor: 'var(--border-soft)' }}
          />
          <button
            onClick={add}
            className="flex items-center justify-center rounded-lg px-2.5 text-white"
            style={{ backgroundColor: 'var(--accent)' }}
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 space-y-1.5 overflow-y-auto" style={{ maxHeight: '200px' }}>
        {loading ? (
          <div className="space-y-2">
            <div className="skeleton h-8 w-full" />
            <div className="skeleton h-8 w-full" />
            <div className="skeleton h-8 w-full" />
          </div>
        ) : todos.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted">No tasks yet. Add one above.</p>
        ) : (
          todos.map((t) => (
            <div
              key={t.id}
              className="group flex items-center gap-2 rounded-lg border border-soft px-3 py-2 transition-colors hover:border-strong"
              style={{ borderColor: 'var(--border-soft)' }}
            >
              <button
                onClick={() => toggle(t)}
                className={`flex h-4 w-4 flex-none items-center justify-center rounded border transition-colors ${
                  t.completed ? 'border-transparent' : 'border-strong'
                }`}
                style={t.completed ? { backgroundColor: 'var(--accent)', borderColor: 'var(--accent)' } : {}}
              >
                {t.completed && <Check className="h-3 w-3 text-white" />}
              </button>
              <span className={`flex-1 text-sm ${t.completed ? 'text-muted line-through' : 'text-primary'}`}>
                {t.title}
              </span>
              {t.due_date && (
                <span className={`flex items-center gap-1 text-[11px] ${overdue(t.due_date) && !t.completed ? 'text-rose-400' : 'text-muted'}`}>
                  <Calendar className="h-3 w-3" />
                  {new Date(t.due_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </span>
              )}
              <button
                onClick={() => remove(t.id)}
                className="rounded p-1 text-muted opacity-0 transition-opacity hover:text-rose-400 group-hover:opacity-100"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))
        )}
      </div>
    </WidgetShell>
  );
}
