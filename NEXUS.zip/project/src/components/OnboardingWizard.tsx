import { useState } from 'react';
import { Radar, ArrowRight, ArrowLeft, Check, Layout, Palette, User } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useSettings } from '@/context/SettingsContext';
import { ACCENTS } from '@/lib/theme';
import { supabase } from '@/lib/supabase';

const WIDGET_OPTIONS = [
  { id: 'clock', label: 'Clock' },
  { id: 'weather', label: 'Weather' },
  { id: 'todos', label: 'To-Do List' },
  { id: 'notes', label: 'Notes' },
  { id: 'pomodoro', label: 'Focus Timer' },
  { id: 'news', label: 'News Feed' },
];

export default function OnboardingWizard() {
  const { user, profile, refreshProfile } = useAuth();
  const { settings, updateSettings } = useSettings();
  const [step, setStep] = useState(0);
  const [name, setName] = useState(profile?.display_name ?? '');
  const [theme, setTheme] = useState<'dark' | 'light'>(settings?.theme ?? 'dark');
  const [accent, setAccent] = useState(settings?.accent_color ?? 'sky');
  const [widgets, setWidgets] = useState<Record<string, boolean>>(
    settings?.widget_visibility ?? { clock: true, weather: true, todos: true, notes: true, pomodoro: true, news: true }
  );

  const steps = ['name', 'theme', 'widgets'];

  const finish = async () => {
    if (user) {
      await supabase.from('profiles').update({ display_name: name }).eq('id', user.id);
      await refreshProfile();
    }
    await updateSettings({
      theme,
      accent_color: accent,
      widget_visibility: widgets,
      onboarded: true,
    });
  };

  const next = () => {
    if (step < steps.length - 1) setStep(step + 1);
    else finish();
  };

  const prev = () => setStep((s) => Math.max(0, s - 1));

  const toggleWidget = (id: string) =>
    setWidgets((prev) => ({ ...prev, [id]: !prev[id] }));

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-4">
      <div className="pointer-events-none absolute inset-0" style={{ background: 'var(--bg-base)' }} />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full opacity-20 blur-3xl" style={{ background: 'var(--accent)' }} />

      <div className="relative w-full max-w-md slide-up">
        <div className="mb-6 flex flex-col items-center gap-2">
          <Radar className="h-10 w-10 text-accent" style={{ color: 'var(--accent)' }} />
          <h1 className="text-xl font-bold tracking-wide">Welcome to NEXUS</h1>
          <p className="text-sm text-secondary">Let's set up your dashboard in 30 seconds.</p>
        </div>

        <div className="glass-elevated rounded-2xl p-6">
          {/* Progress dots */}
          <div className="mb-5 flex justify-center gap-1.5">
            {steps.map((_, i) => (
              <div
                key={i}
                className="h-1.5 rounded-full transition-all"
                style={{
                  width: i === step ? '24px' : '8px',
                  background: i <= step ? 'var(--accent)' : 'var(--border-strong)',
                }}
              />
            ))}
          </div>

          {/* Step 0: Name */}
          {step === 0 && (
            <div className="fade-in text-center">
              <User className="mx-auto mb-3 h-8 w-8 text-accent" style={{ color: 'var(--accent)' }} />
              <h2 className="mb-1 text-lg font-semibold">What should we call you?</h2>
              <p className="mb-4 text-xs text-secondary">This personalizes your dashboard.</p>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                autoFocus
                className="w-full rounded-lg border border-soft bg-transparent px-4 py-3 text-center text-sm text-primary placeholder:text-muted focus:outline-none"
                style={{ borderColor: 'var(--border-soft)' }}
                onKeyDown={(e) => e.key === 'Enter' && next()}
              />
            </div>
          )}

          {/* Step 1: Theme */}
          {step === 1 && (
            <div className="fade-in">
              <Palette className="mx-auto mb-3 h-8 w-8 text-accent" style={{ color: 'var(--accent)' }} />
              <h2 className="mb-1 text-center text-lg font-semibold">Pick your style</h2>
              <p className="mb-4 text-center text-xs text-secondary">Choose a theme and accent color.</p>
              <div className="mb-4 flex gap-2">
                {(['dark', 'light'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setTheme(t)}
                    className="flex-1 rounded-lg border py-3 text-sm capitalize transition-colors"
                    style={theme === t
                      ? { borderColor: 'var(--accent)', background: 'var(--accent-soft)', color: 'var(--accent)' }
                      : { borderColor: 'var(--border-soft)', color: 'var(--text-secondary)' }}
                  >
                    {t}
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap justify-center gap-2">
                {Object.entries(ACCENTS).map(([key, a]) => (
                  <button
                    key={key}
                    onClick={() => setAccent(key)}
                    className="flex h-9 w-9 items-center justify-center rounded-full border-2 transition-transform hover:scale-110"
                    style={{ borderColor: accent === key ? a.main : 'transparent', background: a.soft }}
                  >
                    <span className="h-5 w-5 rounded-full" style={{ background: a.main }} />
                    {accent === key && <Check className="absolute h-3 w-3 text-white" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Widgets */}
          {step === 2 && (
            <div className="fade-in">
              <Layout className="mx-auto mb-3 h-8 w-8 text-accent" style={{ color: 'var(--accent)' }} />
              <h2 className="mb-1 text-center text-lg font-semibold">Choose your widgets</h2>
              <p className="mb-4 text-center text-xs text-secondary">You can change these anytime in Settings.</p>
              <div className="grid grid-cols-2 gap-2">
                {WIDGET_OPTIONS.map((w) => (
                  <button
                    key={w.id}
                    onClick={() => toggleWidget(w.id)}
                    className="flex items-center gap-2 rounded-lg border px-3 py-2.5 text-sm transition-colors"
                    style={widgets[w.id]
                      ? { borderColor: 'var(--accent)', background: 'var(--accent-soft)', color: 'var(--accent)' }
                      : { borderColor: 'var(--border-soft)', color: 'var(--text-secondary)' }}
                  >
                    {widgets[w.id] ? <Check className="h-4 w-4" /> : <div className="h-4 w-4 rounded border" style={{ borderColor: 'var(--border-strong)' }} />}
                    {w.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Nav */}
          <div className="mt-6 flex items-center justify-between">
            <button
              onClick={prev}
              disabled={step === 0}
              className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm text-secondary transition-colors hover:text-primary disabled:opacity-30"
            >
              <ArrowLeft className="h-4 w-4" /> Back
            </button>
            <button
              onClick={next}
              className="flex items-center gap-1.5 rounded-lg px-5 py-2 text-sm font-semibold text-white"
              style={{ backgroundColor: 'var(--accent)' }}
            >
              {step === steps.length - 1 ? 'Finish' : 'Next'}
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
