import { useEffect, useRef, useState } from 'react';
import { Terminal, Circle } from 'lucide-react';

type Log = {
  id: number;
  time: string;
  level: 'INFO' | 'WARN' | 'OK' | 'SYNC';
  msg: string;
};

const POOL: Omit<Log, 'id' | 'time'>[] = [
  { level: 'OK', msg: 'Telemetry handshake established with node-04' },
  { level: 'SYNC', msg: 'Synced 1,204 records from upstream shard' },
  { level: 'INFO', msg: 'Heartbeat: all 12 nodes responsive' },
  { level: 'OK', msg: 'Cache warmed — 98.2% hit rate' },
  { level: 'WARN', msg: 'Latency spike on edge-02 (148ms)' },
  { level: 'INFO', msg: 'Scheduled rotation of signing keys complete' },
  { level: 'OK', msg: 'Backup snapshot committed to cold storage' },
  { level: 'SYNC', msg: 'Reconciled ledger segment 0x4F' },
  { level: 'INFO', msg: 'Queue depth: 42 pending events' },
  { level: 'WARN', msg: 'Rate limit approaching threshold on /v1/ingest' },
  { level: 'OK', msg: 'Auto-scaler provisioned 3 new workers' },
  { level: 'SYNC', msg: 'Mirror region us-west-2 in sync' },
];

const COLOR: Record<Log['level'], string> = {
  INFO: 'text-sky-400',
  WARN: 'text-amber-400',
  OK: 'text-emerald-400',
  SYNC: 'text-fuchsia-400',
};

export default function ActivityFeed() {
  const [logs, setLogs] = useState<Log[]>([]);
  const idRef = useRef(0);

  useEffect(() => {
    const seed = () => {
      const now = new Date();
      const arr: Log[] = [];
      for (let i = 0; i < 6; i++) {
        const e = POOL[Math.floor(Math.random() * POOL.length)];
        const t = new Date(now.getTime() - i * 4000);
        arr.push({
          id: idRef.current++,
          time: t.toLocaleTimeString('en-US', { hour12: false }),
          level: e.level,
          msg: e.msg,
        });
      }
      setLogs(arr.reverse());
    };
    seed();
    const id = setInterval(() => {
      const e = POOL[Math.floor(Math.random() * POOL.length)];
      setLogs((prev) => [
        ...prev.slice(-40),
        {
          id: idRef.current++,
          time: new Date().toLocaleTimeString('en-US', { hour12: false }),
          level: e.level,
          msg: e.msg,
        },
      ]);
    }, 2200);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="flex h-full flex-col rounded-2xl border border-white/5 bg-slate-950/40 p-4 backdrop-blur-md">
      <div className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-slate-400">
        <Terminal className="h-3.5 w-3.5 text-sky-400" />
        Live Activity Stream
      </div>
      <div className="flex-1 space-y-1.5 overflow-y-auto font-mono text-[12px] leading-relaxed">
        {logs.map((l) => (
          <div
            key={l.id}
            className="flex items-start gap-2 border-b border-white/5 pb-1.5 last:border-0"
          >
            <Circle className={`mt-1 h-1.5 w-1.5 flex-none ${COLOR[l.level]}`} fill="currentColor" />
            <span className="text-slate-600">{l.time}</span>
            <span className={`font-semibold ${COLOR[l.level]}`}>{l.level}</span>
            <span className="text-slate-300">{l.msg}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
