import { useCallback, useEffect, useState } from 'react';
import { Pin, PinOff, Trash2, Plus, Loader2, Flag } from 'lucide-react';
import { supabase, type Note } from '@/lib/supabase';

const PRIORITY_STYLES: Record<Note['priority'], string> = {
  low: 'border-l-emerald-400 text-emerald-400',
  normal: 'border-l-sky-400 text-sky-400',
  high: 'border-l-rose-400 text-rose-400',
};

export default function NotesPanel() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [content, setContent] = useState('');
  const [priority, setPriority] = useState<Note['priority']>('normal');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('notes')
      .select('*')
      .order('pinned', { ascending: false })
      .order('created_at', { ascending: false });
    if (!error && data) setNotes(data as Note[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const add = async () => {
    const text = content.trim();
    if (!text || saving) return;
    setSaving(true);
    const { data, error } = await supabase
      .from('notes')
      .insert({ content: text, priority })
      .select()
      .single();
    if (!error && data) {
      setNotes((prev) => [data as Note, ...prev].sort((a, b) => Number(b.pinned) - Number(a.pinned)));
      setContent('');
    }
    setSaving(false);
  };

  const togglePin = async (n: Note) => {
    const { error } = await supabase
      .from('notes')
      .update({ pinned: !n.pinned, updated_at: new Date().toISOString() })
      .eq('id', n.id);
    if (!error) load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from('notes').delete().eq('id', id);
    if (!error) setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  return (
    <div className="flex h-full flex-col rounded-2xl border border-white/5 bg-slate-950/40 p-4 backdrop-blur-md">
      <div className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-slate-400">
        <Flag className="h-3.5 w-3.5 text-sky-400" />
        Quick Notes
        <span className="ml-auto rounded-full bg-white/5 px-2 py-0.5 text-[10px] text-slate-400">
          {notes.length}
        </span>
      </div>

      <div className="mb-3 space-y-2">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) add();
          }}
          placeholder="Jot something down… (⌘+Enter to save)"
          rows={2}
          className="w-full resize-none rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:border-sky-400/50 focus:outline-none focus:ring-1 focus:ring-sky-400/30"
        />
        <div className="flex items-center gap-2">
          <div className="flex gap-1">
            {(['low', 'normal', 'high'] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPriority(p)}
                className={`rounded-md px-2 py-1 text-[11px] font-medium capitalize transition-colors ${
                  priority === p
                    ? 'bg-sky-500/20 text-sky-200 ring-1 ring-sky-400/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
          <button
            onClick={add}
            disabled={saving || !content.trim()}
            className="ml-auto flex items-center gap-1.5 rounded-md bg-sky-500/90 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-sky-400 disabled:opacity-40"
          >
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
            Save
          </button>
        </div>
      </div>

      <div className="flex-1 space-y-2 overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center py-8 text-slate-500">
            <Loader2 className="h-4 w-4 animate-spin" />
          </div>
        ) : notes.length === 0 ? (
          <p className="py-8 text-center text-sm text-slate-500">
            No notes yet. Your quick thoughts persist across reloads.
          </p>
        ) : (
          notes.map((n) => (
            <div
              key={n.id}
              className={`group rounded-lg border border-white/5 border-l-2 bg-white/[0.03] px-3 py-2 ${PRIORITY_STYLES[n.priority].split(' ')[0]}`}
            >
              <div className="flex items-start gap-2">
                <p className="flex-1 text-sm text-slate-200">{n.content}</p>
                <div className="flex flex-none items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <button
                    onClick={() => togglePin(n)}
                    title={n.pinned ? 'Unpin' : 'Pin'}
                    className="rounded p-1 text-slate-400 hover:bg-white/10 hover:text-sky-300"
                  >
                    {n.pinned ? <PinOff className="h-3.5 w-3.5" /> : <Pin className="h-3.5 w-3.5" />}
                  </button>
                  <button
                    onClick={() => remove(n.id)}
                    title="Delete"
                    className="rounded p-1 text-slate-400 hover:bg-white/10 hover:text-rose-300"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
              <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-500">
                <span className={PRIORITY_STYLES[n.priority].split(' ')[1]}>
                  {n.priority}
                </span>
                {n.pinned && <span className="text-amber-400">pinned</span>}
                <span>{new Date(n.created_at).toLocaleString()}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
