import { useState } from 'react';
import {
  Settings, X, Palette, Layout, Monitor, Sun, Moon, Check, User, LogOut,
} from 'lucide-react';
import { useSettings } from '@/context/SettingsContext';
import { useAuth } from '@/context/AuthContext';
import { ACCENTS } from '@/lib/theme';
import { supabase, type BackgroundStyle } from '@/lib/supabase';

const BACKGROUNDS: { id: BackgroundStyle; label: string }[] = [
  { id: 'particles', label: 'Particles' },
  { id: 'grid', label: 'Grid' },
  { id: 'aurora', label: 'Aurora' },
  { id: 'none', label: 'None' },
];

const WIDGET_OPTIONS = [
  { id: 'clock', label: 'Clock' },
  { id: 'weather', label: 'Weather' },
  { id: 'todos', label: 'To-Do List' },
  { id: 'notes', label: 'Notes' },
  { id: 'pomodoro', label: 'Focus Timer' },
  { id: 'news', label: 'News Feed' },
];

export default function SettingsPanel({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const { settings, updateSettings, toggleWidget } = useSettings();
  const { profile, refreshProfile, signOut } = useAuth();
  const [name, setName] = useState(profile?.display_name ?? '');

  if (!open) return null;

  const saveName = async () => {
    await supabase.from('profiles').update({ display_name: name }).eq('id', profile!.id);
    await refreshProfile();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div
        className="relative h-full w-full max-w-md overflow-y-auto slide-up border-l border-strong bg-slate-950/95 backdrop-blur-xl"
        style={{ borderColor: 'var(--border-strong)' }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-soft bg-slate-950/80 px-5 py-4 backdrop-blur-xl" style={{ borderColor: 'var(--border-soft)' }}>
          <div className="flex items-center gap-2">
            <Settings className="h-4 w-4 text-accent" style={{ color: 'var(--accent)' }} />
            <h2 className="text-sm font-semibold uppercase tracking-wider">Settings</h2>
          </div>
          <button onClick={onClose} className="rounded p-1 text-muted hover:text-primary">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-6 p-5">
          {/* Profile */}
          <section>
            <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-secondary">
              <User className="h-3.5 w-3.5" /> Profile
            </h3>
            <div className="flex items-center gap-2">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                className="flex-1 rounded-lg border border-soft bg-transparent px-3 py-2 text-sm text-primary placeholder:text-muted focus:outline-none"
                style={{ borderColor: 'var(--border-soft)' }}
              />
              <button onClick={saveName} className="rounded-lg px-3 py-2 text-xs font-semibold text-white" style={{ backgroundColor: 'var(--accent)' }}>
                Save
              </button>
            </div>
          </section>

          {/* Theme */}
          <section>
            <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-secondary">
              <Sun className="h-3.5 w-3.5" /> Theme
            </h3>
            <div className="flex gap-2">
              {(['dark', 'light'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => updateSettings({ theme: t })}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border py-2.5 text-sm capitalize transition-colors"
                  style={settings?.theme === t
                    ? { borderColor: 'var(--accent)', background: 'var(--accent-soft)', color: 'var(--accent)' }
                    : { borderColor: 'var(--border-soft)', color: 'var(--text-secondary)' }}
                >
                  {t === 'dark' ? <Moon className="h-3.5 w-3.5" /> : <Sun className="h-3.5 w-3.5" />}
                  {t}
                </button>
              ))}
            </div>
          </section>

          {/* Accent */}
          <section>
            <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-secondary">
              <Palette className="h-3.5 w-3.5" /> Accent Color
            </h3>
            <div className="flex flex-wrap gap-2">
              {Object.entries(ACCENTS).map(([key, a]) => (
                <button
                  key={key}
                  onClick={() => updateSettings({ accent_color: key })}
                  className="flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs transition-colors"
                  style={settings?.accent_color === key
                    ? { borderColor: a.main, background: a.soft }
                    : { borderColor: 'var(--border-soft)' }}
                >
                  <span className="h-4 w-4 rounded-full" style={{ background: a.main }} />
                  {a.name}
                  {settings?.accent_color === key && <Check className="h-3 w-3" style={{ color: a.main }} />}
                </button>
              ))}
            </div>
          </section>

          {/* Background */}
          <section>
            <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-secondary">
              <Monitor className="h-3.5 w-3.5" /> Background
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {BACKGROUNDS.map((b) => (
                <button
                  key={b.id}
                  onClick={() => updateSettings({ background: b.id })}
                  className="rounded-lg border py-2.5 text-sm transition-colors"
                  style={settings?.background === b.id
                    ? { borderColor: 'var(--accent)', background: 'var(--accent-soft)', color: 'var(--accent)' }
                    : { borderColor: 'var(--border-soft)', color: 'var(--text-secondary)' }}
                >
                  {b.label}
                </button>
              ))}
            </div>
          </section>

          {/* Widgets */}
          <section>
            <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-secondary">
              <Layout className="h-3.5 w-3.5" /> Widgets
            </h3>
            <p className="mb-2 text-xs text-muted">Toggle which widgets appear on your dashboard. Drag to reorder in the main view.</p>
            <div className="space-y-1.5">
              {WIDGET_OPTIONS.map((w) => {
                const visible = settings?.widget_visibility?.[w.id] ?? true;
                return (
                  <label
                    key={w.id}
                    className="flex cursor-pointer items-center justify-between rounded-lg border border-soft px-3 py-2 transition-colors hover:border-strong"
                    style={{ borderColor: 'var(--border-soft)' }}
                  >
                    <span className="text-sm text-primary">{w.label}</span>
                    <button
                      onClick={() => toggleWidget(w.id)}
                      className="relative h-5 w-9 rounded-full transition-colors"
                      style={{ background: visible ? 'var(--accent)' : 'var(--border-strong)' }}
                    >
                      <span
                        className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform"
                        style={{ transform: visible ? 'translateX(18px)' : 'translateX(2px)' }}
                      />
                    </button>
                  </label>
                );
              })}
            </div>
          </section>

          {/* Account */}
          <section className="border-t border-soft pt-4" style={{ borderColor: 'var(--border-soft)' }}>
            <button
              onClick={signOut}
              className="flex w-full items-center justify-center gap-2 rounded-lg border border-rose-500/30 py-2.5 text-sm text-rose-400 transition-colors hover:bg-rose-500/10"
            >
              <LogOut className="h-4 w-4" /> Sign Out
            </button>
          </section>
        </div>
      </div>
    </div>
  );
}
